from flask import Flask, render_template, request
import openai
import requests
from googleapiclient.discovery import build

app = Flask(__name__)

# API keys
OPENAI_API_KEY = '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'
PERPLEXITY_API_KEY = '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'
YOUTUBE_API_KEY = 'AIzaSyBxu0RUNvjFoiYqTOC-aCYzxJQyVpkA8cQ'
youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)
openai.api_key = OPENAI_API_KEY

def live_search(career, country, budget):
    perplexity_api_url = f"https://www.perplexity.ai/search?query=best+courses+for+{career}+in+{country}+under+{budget}"
    try:
        perplexity_response = requests.get(perplexity_api_url)
        perplexity_response.raise_for_status()
        perplexity_data = perplexity_response.json()

        if 'result' in perplexity_data:
            result = perplexity_data['result']
            course = result.get('course', 'Not available')
            reason = result.get('reason', 'Not available')
            colleges = result.get('colleges', ['Not available', 'Not available', 'Not available'])
            details = result.get('details', 'Not available')
            lifecycle = result.get('lifecycle', 'Not available')
        else:
            course = 'Not available'
            reason = 'Not available'
            colleges = ['Not available', 'Not available', 'Not available']
            details = 'Not available'
            lifecycle = 'Not available'
    except requests.exceptions.RequestException as e:
        print(f"Request exception: {e}")
        course = 'Error in fetching course information'
        reason = 'Error in fetching course information'
        colleges = ['Error', 'Error', 'Error']
        details = 'Error'
        lifecycle = 'Error'

    return {
        "course": course,
        "reason": reason,
        "colleges": colleges,
        "details": details,
        "lifecycle": lifecycle
    }

def fetch_videos(career, country, budget):
    query = f"{career} in {country} under {budget}"
    youtube_api_url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q={query}&type=video&maxResults=3&key={YOUTUBE_API_KEY}"
    
    try:
        youtube_response = requests.get(youtube_api_url)
        youtube_response.raise_for_status()
        youtube_data = youtube_response.json()

        if 'items' in youtube_data:
            video_list = []
            for item in youtube_data['items']:
                video_id = item['id']['videoId']
                title = item['snippet']['title']
                link = f"https://www.youtube.com/watch?v={video_id}"
                video_list.append({"title": title, "link": link})
        else:
            video_list = [{'title': 'Not available', 'link': 'Not available'}] * 3
    except requests.exceptions.RequestException as e:
        print(f"Request exception: {e}")
        video_list = [{'title': 'Error', 'link': 'Error'}] * 3

    return video_list

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        career = request.form['career']
        country = request.form['country']
        budget = int(request.form['budget'])

        perplexity_info = live_search(career, country, budget)
        videos = fetch_videos(career, country, budget)
        
        prompt = (
            f"Based on the user inputs:\n\n"
            f"Career Aspiration: {career}\n"
            f"Preferred Country: {country}\n"
            f"Maximum Budget: {budget}\n\n"
            f"Please provide detailed information for the following:\n\n"
            f"1. Course: What is the best course for this career aspiration?\n"
            f"2. Why this course: Why is this course suitable for the user's career aspiration?\n"
            f"3. Top 3 Colleges: List the top 3 colleges offering this course.\n"
            f"4. Course Details: Provide details about the course curriculum and structure.\n"
            f"5. Lifecycle: What are the career opportunities and lifecycle after completing this course?\n"
        )

        openai_response = openai.Completion.create(
            model="gpt-3.5-turbo-instruct",
            prompt=prompt,
            max_tokens=800
        )
        
        ai_result = openai_response.choices[0].text.strip()
        
        # Splitting the response into sections
        sections = ai_result.split('\n')
        
        # Initializing the output dictionary
        formatted_response = {
            "course": "Not available",
            "reason": "Not available",
            "colleges": ["Not available", "Not available", "Not available"],
            "details": "Not available",
            "lifecycle": "Not available",
            "videos": videos
        }

        # Populating the dictionary with extracted information
        for i in range(len(sections)):
            if sections[i].startswith("1. Course:"):
                formatted_response["course"] = sections[i].split("1. Course:")[1].strip()
            elif sections[i].startswith("2. Why this course:"):
                formatted_response["reason"] = sections[i].split("2. Why this course:")[1].strip()
            elif sections[i].startswith("3. Top 3 Colleges:"):
                formatted_response["colleges"] = [sections[i+1].strip('- '), sections[i+2].strip('- '), sections[i+3].strip('- ')]
            elif sections[i].startswith("4. Course Details:"):
                formatted_response["details"] = sections[i].split("4. Course Details:")[1].strip()
            elif sections[i].startswith("5. Lifecycle:"):
                formatted_response["lifecycle"] = sections[i].split("5. Lifecycle:")[1].strip()

        return render_template('result.html', response=formatted_response)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)